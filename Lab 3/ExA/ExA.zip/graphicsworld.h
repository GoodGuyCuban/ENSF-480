#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H

class GraphicsWorld{
    public:
        void run();
};

#endif